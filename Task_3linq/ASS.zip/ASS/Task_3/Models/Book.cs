﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_3.Models
{
    public   class Book
    {
        // Q1: Why did the property "Id" become a Primary Key without any explicit configuration?
        // Answer: Because EF Core uses conventions. A property named "Id" is automatically recognized as the Primary Key.

        // Q2: Why is "Country" nullable in the database while "Price" is not?
        // Answer: Country is nullable because it is declared as string? in C#, while Price is not nullable because decimal is a non-nullable value type.
        public int Id { get; set; }

        public string Title { get; set; }

        public decimal Price { get; set; }

        public DateTime? PublishedDate { get; set; }

    }
}
